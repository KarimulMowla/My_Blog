#include <bits/stdc++.h>
using namespace std;
int main()
{
    string s;
    cin >> s;
    int flag = 0;
    for (int i = 0; i < s.length() - 1; i++)
    {
        if (s[i] == 'a' || s[i] == 'b')
        {
            flag = 1;
            if (s[i] == 'a' && s[i + 1] == 'b')
            {
                flag = 1;
                break;
            }
        }
        else
        {
            flag = 0;
            break;
        }
    }
    if (flag == 1)
    {
        cout << "accept" << endl;
    }
    else
    {
        cout << "Rejected" << endl;
    }

    return 0;
}